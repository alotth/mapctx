#!/bin/sh
set -eu
cd /tmp/mapctx-t120-review-attempt3/preservation
MAPCTX_HOME=/tmp/mapctx-t120-review-attempt3/preservation/home T120_REVIEW_DIR=/tmp/mapctx-t120-review-attempt3/preservation T120_BASELINE=/tmp/mapctx-t120-baseline/pre-review-attempt3-latest node preservation.cjs > preservation.log 2>&1
